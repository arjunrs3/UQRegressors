# uqregressors.metrics.metrics

This script contains many metrics which can be used to compare the efficacy of different models. The methods are described along with their functions below. 
::: uqregressors.metrics.metrics
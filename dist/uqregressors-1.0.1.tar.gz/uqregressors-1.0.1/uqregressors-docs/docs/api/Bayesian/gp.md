# uqregressors.bayesian.gaussian_process

This is a compatibility wrapper of the [scikit-learn Gaussian Process Regressor](https://scikit-learn.org/stable/modules/gaussian_process.html) 
such that predictions return intervals rather than means and/or standard deviations. 

::: uqregressors.bayesian.gaussian_process
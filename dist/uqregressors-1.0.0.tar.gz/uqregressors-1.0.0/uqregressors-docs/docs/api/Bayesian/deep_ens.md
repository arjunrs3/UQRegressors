# uqregressors.bayesian.deep_ens

Deep Ensembles are implemented as in [Lakshimnarayanan et al. 2017](https://arxiv.org/abs/1612.01474).
::: uqregressors.bayesian.deep_ens

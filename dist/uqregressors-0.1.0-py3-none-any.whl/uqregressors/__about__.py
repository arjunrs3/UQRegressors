# SPDX-FileCopyrightText: 2025-present arshah2 <119633165+arjunrs3@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"

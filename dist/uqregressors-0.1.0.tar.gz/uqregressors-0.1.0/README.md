# uqregressors

[![PyPI - Version](https://img.shields.io/pypi/v/uqregressors.svg)](https://pypi.org/project/uqregressors)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/uqregressors.svg)](https://pypi.org/project/uqregressors)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install uqregressors
```

## License

`uqregressors` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

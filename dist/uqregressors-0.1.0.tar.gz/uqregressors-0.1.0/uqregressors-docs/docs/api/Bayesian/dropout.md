# uqregressors.bayesian.dropout

Monte Carlo Dropout is implemented as in [Gal and Ghahramani 2016](https://arxiv.org/abs/1506.02142).
::: uqregressors.bayesian.dropout
